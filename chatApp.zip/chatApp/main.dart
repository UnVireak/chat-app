import 'package:flutter/material.dart';

import 'chat_app_module/chat_app.dart';

void main() {
  runApp(const ChatApp());
}

